from django.contrib import admin

from accounts.models import *

admin.site.register(CustomerAccount)
admin.site.register(Transaction)
