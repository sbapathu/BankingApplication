from django.urls import path, include
from accounts.views import *
from rest_framework.routers import DefaultRouter

# app_name = 'Accounts'

router = DefaultRouter()
router.register(r'Users', UserDetails, basename='user')
router1 = DefaultRouter()
router1.register(r'Bank_account', AccountDetails, basename='account')
# urlpatterns = router.urls
urlpatterns = [
    path(r'User/', include((router.urls))),
    path(r'BankAccount/', include((router1.urls))),
    path(r'Transaction/', TransferToAccount.as_view(), name='TransferToAccount'),
]
