from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions
from django.contrib.auth.models import User
from accounts.serializers import *
from rest_framework import viewsets, status
from accounts.models import *
from rest_framework.generics import CreateAPIView, UpdateAPIView, ListAPIView, DestroyAPIView, RetrieveAPIView

class UserDetails(viewsets.ModelViewSet):
    """
    View to list all users in the system.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def list(self, request, *args, **kwargs):
        data = list(User.objects.all().values())
        return Response(data)

    def retrieve(self, request, *args, **kwargs):
        data = list(User.objects.filter(id=kwargs['pk']).values())
        return Response(data)

    def create(self, request, *args, **kwargs):
        user_serializer_data = UserSerializer(data=request.data)
        if user_serializer_data.is_valid():
            user_serializer_data.save()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "User Added", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "please fill the details", "status": status_code})

    def destroy(self, request, *args, **kwargs):
        user_data = User.objects.filter(id=kwargs['pk'])
        if user_data:
            user_data.delete()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "User deleted", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "User data not found", "status": status_code})

    def update(self, request, *args, **kwargs):
        user_details = User.objects.get(id=kwargs['pk'])
        user_serializer_data = UserSerializer(
            user_details, data=request.data, partial=True)
        if user_serializer_data.is_valid():
            user_serializer_data.save()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "User Updated", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "User data Not found", "status": status_code})

class AccountDetails(viewsets.ModelViewSet):
    """
    View to list all users in the system.
    """
    queryset = CustomerAccount.objects.all()
    serializer_class = AccountSerializer

    def list(self, request, *args, **kwargs):
        data = list(CustomerAccount.objects.all().values())
        return Response(data)

    def retrieve(self, request, *args, **kwargs):
        data = list(CustomerAccount.objects.filter(id=kwargs['pk']).values())
        return Response(data)

    def create(self, request, *args, **kwargs):
        account_serializer_data = AccountSerializer(data=request.data)
        if account_serializer_data.is_valid():
            AccountSerializer.create(self,request.data)
            status_code = status.HTTP_201_CREATED
            return Response({"message": "Bank Account Created", "status": status_code})
        else:
            print("errors:::",account_serializer_data.errors)
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": account_serializer_data.errors, "status": status_code})

    def destroy(self, request, *args, **kwargs):
        account_data = CustomerAccount.objects.filter(id=kwargs['pk'])
        if account_data:
            account_data.delete()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "Bank account deleted", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "bank account data not found", "status": status_code})

    def update(self, request, *args, **kwargs):
        account_details = CustomerAccount.objects.get(id=kwargs['pk'])
        account_serializer_data = AccountSerializer(
            account_details, data=request.data, partial=True)
        if account_serializer_data.is_valid():
            account_serializer_data.save()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "Bank Account Updated", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "Account data Not found", "status": status_code})

class TransferToAccount(CreateAPIView):
    
    serializer_class = TransactionSerializers
    def get (self, request):
        data = list(Transaction.objects.all().values())
        return Response(data)
    
    def post (self, request):
        serializer = TransactionSerializers(data=request.data)
        if serializer.is_valid(raise_exception=ValueError):
            trans_obj = TransactionSerializers.create(self, request.data)
            if trans_obj['status'] == False:
                return Response({trans_obj['message']},status=status.HTTP_400_BAD_REQUEST)
            return Response({'message': 'Transaction done successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.error_messages, status=status.HTTP_400_BAD_REQUEST)