from decimal import Decimal
from django.db import models
from django.contrib.auth.models import User
import uuid
from accounts.constants import *

class CustomerAccount(models.Model):
    id = models.UUIDField(primary_key=True, unique=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(User, related_name='account_user',on_delete=models.CASCADE)
    account_number = models.IntegerField(unique=True, default=random_string)
    account_type = models.CharField(max_length=54, choices=ACCOUNT_TYPES)
    account_status = models.CharField(max_length=54, choices=ACCOUNT_STATUS)
    gender = models.CharField(max_length=1, choices=GENDER)
    birth_date = models.DateField(null=True, blank=True)
    account_balance = models.DecimalField(default=0,max_digits=12,decimal_places=2)
    created_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now_add=True)
        
    def __str__(self):
        return str(self.account_number) 

class Transaction(models.Model):
    transaction_id = models.UUIDField(primary_key=True, unique=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="transaction_user")
    trans_description = models.CharField(max_length=1000, null=True, blank=True)
    sender = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="sender")
    receiver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="receiver")
    sender_account = models.ForeignKey(CustomerAccount,null=True,related_name='sender_account',on_delete=models.CASCADE)
    receiver_account = models.ForeignKey(CustomerAccount,null=True,related_name='receiver_account',on_delete=models.CASCADE)
    amount = models.DecimalField(decimal_places=2,max_digits=12,default=0.00)
    status = models.CharField(choices=TRANSACTION_STATUS ,max_length=100, default="pending")
    transaction_type = models.CharField(choices=TRANSACTION_TYPE_CHOICES,max_length=100, default='')
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return str(self.transaction_id)