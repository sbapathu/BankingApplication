from rest_framework import serializers
from accounts.models import *
from django.contrib.auth.models import User
from accounts.constants import *
import uuid
from decimal import Decimal
from rest_framework.validators import UniqueValidator

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'is_active']

class AccountSerializer(serializers.ModelSerializer):
    user = UserSerializer(required=True)
    account_number = serializers.IntegerField( default=random_string,
                                    validators=[UniqueValidator(queryset=CustomerAccount.objects.all())])
    account_balance = serializers.DecimalField(default=0,max_digits=12,decimal_places=2)
    account_type = serializers.ChoiceField(choices=ACCOUNT_STATUS)
    account_status = serializers.ChoiceField(choices=ACCOUNT_TYPES)
    gender = serializers.ChoiceField(choices=GENDER, default='m')
    birth_date = serializers.DateField(format="%d-%b-%Y")
    
    class Meta:
        model = CustomerAccount
        fields = "__all__"
        
    def create(self, validated_data):
        """
        Create and return a new `account` instance, given the validated data.
        """
        user_data = validated_data.pop('user')
        user_obj,created = User.objects.get_or_create(**user_data)
        validated_data['user'] = user_obj
        return CustomerAccount.objects.create(**validated_data)

class TransactionSerializers(serializers.ModelSerializer):
    sender_account = serializers.IntegerField()
    receiver_account = serializers.IntegerField(required=True)
    amount = serializers.DecimalField(default=0,max_digits=12,decimal_places=2)
    transaction_type = serializers.ChoiceField(choices=TRANSACTION_TYPE_CHOICES, default='TRANSFER')
    trans_description = serializers.CharField(max_length=1000, allow_null=True)
    
    class Meta:
        model = Transaction
        fields = ['sender_account', 'receiver_account', 'amount', 'transaction_type', 'trans_description']

 
    def create(self, validated_data):
        """
        Create and return a new `account` instance, given the validated data.
        """
        print("validated_data::::::",validated_data)
        try:
            if float(validated_data.get('amount')) <= float(0):
                return {"message": "Amount should not be negative", "status": False}
            
            if validated_data.get('transaction_type') == 'TRANSFER':
                if validated_data.get('sender_account', None) in [0, None, 'null', 'NULL'] or validated_data.get('receiver_account', None) in [0, None, 'null', 'NULL']:
                    return {"message": "Sender and Receiver Account mandatory for Transfer the amount", "status": False}
                
                sender_details = CustomerAccount.objects.filter(account_number=validated_data.get('sender_account'))
                receiver_details = CustomerAccount.objects.filter(account_number=validated_data.get('receiver_account'))
                
                if not sender_details or not receiver_details:
                    return {"message": "Sender/Receiver Account should be valid", "status": False} 
                
                validated_data['sender_account'] = sender_details[0]
                validated_data['receiver_account'] = receiver_details[0]
                validated_data['status'] = 'Completed'
                validated_data['user'] = sender_details[0].user
                validated_data['sender'] = sender_details[0].user
                validated_data['receiver'] = receiver_details[0].user
                
                receiver_details.update(account_balance = receiver_details[0].account_balance + 
                                                        Decimal(validated_data.get('amount')))
                
                sender_details.update(account_balance = sender_details[0].account_balance - 
                                                        Decimal(validated_data.get('amount')))

            else:
                if validated_data.get('receiver_account', None) in [0, None, 'null', 'NULL']:
                    return {"message": "Receiver Account mandatory for Transfer the amount", "status": False}
                
                receiver_details = CustomerAccount.objects.filter(account_number=validated_data.get('receiver_account'))
                
                if not receiver_details:
                    return {"message": "Receiver Account should be valid", "status": False} 
                    
                validated_data['receiver_account'] = receiver_details[0]
                validated_data['status'] = 'completed'
                validated_data['user'] = receiver_details[0].user
                validated_data['receiver'] = receiver_details[0].user
                validated_data.pop('sender_account')

                if validated_data.get('transaction_type') == 'DEPOSIT':
                    receiver_details.update(account_balance = receiver_details[0].account_balance + 
                                                        Decimal(validated_data.get('amount')))
                else:
                    receiver_details.update(account_balance = receiver_details[0].account_balance - 
                                                        Decimal(validated_data.get('amount')))
            
            trans_obj = Transaction.objects.create(**validated_data)
            if not trans_obj:
                return {"message": "Failed to transfer/deposit/withdraw amount", "status": False} 
        except Exception as err:
            return {"message": err, "status":False}
        return {"message": "Successfully amount transaction done", "status": True} 