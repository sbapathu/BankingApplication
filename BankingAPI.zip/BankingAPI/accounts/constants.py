
import random
def random_string():
    return str(random.randint(10000, 99999))

ACCOUNT_STATUS = (
    ("active", "Active"),
    ("pending", "Pending"),
    ("in-active", "In-active")
)

ACCOUNT_TYPES = (
    ("savings", "savings"),
    ("current", "current")
)

GENDER = (
    ("m", "Male"),
    ("f", "Female"),
    ("o", "Other")
)

TRANSACTION_TYPE_CHOICES = (
    ('',''),
    ('DEPOSIT', 'Deposit'),
    ('WITHDRAW', 'Withdraw'),
    ('TRANSFER', 'TRANSFER'),
)

TRANSACTION_STATUS = (
    ("failed", "failed"),
    ("completed", "completed"),
    ("pending", "pending"),
    ("processing", "processing"),
)